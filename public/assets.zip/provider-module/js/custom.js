/* It's the best idea to write your own JS in custom.js file. So if you want to write JS with your own use this file */
