"use strict"
$(document).ready(function () {
    $('.js-select').select2();
});

