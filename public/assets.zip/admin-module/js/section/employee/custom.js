"use strict"
$(document).ready(function () {
    $('.zone-select').select2({
        placeholder: "Select Zone"
    });
});
