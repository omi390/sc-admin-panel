@extends('errors::minimal')
@section('section')

@endsection
